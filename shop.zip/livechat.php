<?php
include('inc/config.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Live Chat</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">      
		<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">		
		<link href="themes/css/bootstrappage.css" rel="stylesheet"/>

		<link href="themes/css/livechat.css" rel="stylesheet"/>
		
		<!-- global styles -->
		<link href="themes/css/flexslider.css" rel="stylesheet"/>
		<link href="themes/css/main.css" rel="stylesheet"/>

		<!-- scripts -->
		<script src="themes/js/jquery-1.7.2.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>				
		<script src="themes/js/superfish.js"></script>	
		<script src="themes/js/jquery.scrolltotop.js"></script>
		<!--[if lt IE 9]>			
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
    <body>		
		<div id="top-bar" class="container">
			
		</div>
		<div id="wrapper" class="container">
			<section class="navbar main-menu">
				<div class="navbar-inner main-menu">				
					<a href="index.php" class="logo pull-left"><img src="themes/images/logo.png" class="site_logo" alt=""></a>
					<nav id="menu" class="pull-right">
						<ul>
							<li><a href="index.php">Beranda</a></li>															
							<li><a href="products.php">Produk</a>
								<ul>									
									<li><a href="products.php">Kaos</a></li>
								</ul>
							</li>							
							<li><a href="about.php">Tentang Kami</a></li>
							<li><a href="contact.php">Kontak</a></li>
							<li><a href="livechat.php">Live Chat</a></li>
							<li><a href="membership.php">Membership</a></li>
						</ul>
					</nav>
				</div>
			</section>				

			<section class="header_text sub">
			<img class="pageBanner" src="gambar-slide/pagebanner.jpg" alt="New products" >
			<h3><span>Live Chat</span></h3>
				<h5><span>( isikan chat anda pada post chat yang sudah disediakan )</span></h5>
			</section>	

			<section class="main-content">
				<div class="row">
					<div class="span12">						  
					<div class="pesan">
				<table class="art-article" border="0" cellspacing="0" cellpadding="0" style=" margin: 0; width: 100%;">
					<tbody>
						<?php
							$Tampil="SELECT * FROM chat ORDER BY waktu DESC LIMIT 99;";
							$query = mysql_query($Tampil);
							while (	$hasil = mysql_fetch_array ($query)) {
							$komen = stripslashes ($hasil['komen']);
							$waktu = stripslashes ($hasil['waktu']);
							$nama = stripslashes ($hasil['nama']);	
						?>	
						<?php
							echo"
							<div id='atas'>$hasil[nama]<span class='waktu'>$hasil[waktu]</span></div>
							<div id='pesan'>$hasil[komen]</div>";
							}
						?>
					</tbody>
				</table>  
			</div><br>

			<div class="form">
				<form method="POST" name="chat" action="#" enctype="application/x-www-form-urlencoded"><h4>Post your chat:</h4><br>
					
					<p>Name</p><input type="text" placeholder=" Nama Anda" name="nama" maxlength="9" style="width: 95%;"></input><br><br>
					<p>Email</p><input type="text" placeholder=" Alamat email Anda" name="email" maxlength="30" style="width: 95%;"></input><br><br>
					<p>Chat</p><textarea placeholder=" Obrolan Anda" name="komen" rows="2" cols="40" maxlength="120" style="width: 95%;"></textarea><br><br>
					
					<input type="checkbox" name="cek" value="cek" class="art-button"> Confirm you are NOT a spammer</input><br><br>
					<input type="submit" name="submit" value="Send" class="art-button"></input>&nbsp;
					<input type="reset" name="reset" value="Clear" class="art-button"></input>
					
					<?php
						if (isset($_POST['submit'])) {
						$nama	= $_POST['nama'];
						$email	= $_POST['email'];
						$komen	= $_POST['komen'];
						$waktu	= date ("Y-m-d, H:i a");
						$cek	= $_POST['cek'];
						
						if ($_POST['nama']=='Admin') { //validasi kata admin
					?>

						<script language="JavaScript">
							alert('Anda bukan Admin !');
							document.location='livechat.php.php';
						</script>
					<?php
						mysql_close($Open);
					}
					
					if (empty($_POST['nama'])|| empty($_POST['email']) || empty($_POST['komen'])) { //validasi data
					?>
		
						<script language="JavaScript">
							alert('Data yang Anda masukan tidak lengkap !');
							document.location='index.php';
						</script>
					<?php
					}
					
					if (empty($_POST['cek'])) { //validasi data
					?>
						<script language="JavaScript">
							alert('Please Checklist - Confirm you are NOT a spammer !');
							document.location='index.php';
						</script>
					<?php
					}
						else {
							$input_chat = "INSERT INTO chat (nama, email, komen, waktu, cek) VALUES ('$nama', '$email', '$komen', '$waktu', '$cek')";
							$query_input =mysql_query($input_chat);
							if ($query_input) {
						?>
						<script language="JavaScript">
							document.location='livechat.php';
						</script>
					<?php
					}
						else{
							echo'Dbase E';
						}
					}
					}
						mysql_close($Open);
					?>
				</form>
			</div>		
                          	
					</div>
				</div>
			</section>			
			<section id="footer-bar">
				<div class="row">
					<div class="span3">
						<h4>Navigation</h4>
						<ul class="nav">
							<li><a href="index.php">Beranda</a></li>  
							<li><a href="about.php">Tentang Kami</a></li>
							<li><a href="contact.php">Kontak</a></li>
							<li><a href="keranjang.php">Keranjang Belanja</a></li>							
						</ul>					
					</div>
                    <div class="span4"></div>
					<div class="span5">
						<p class="logo"><img src="themes/images/logo.png" class="site_logo" alt=""></p>
						<p>Toko online kami menjual beberapa kaos</p>
						<br/>
						<span class="social_icons">
							<a class="facebook" href="#">Facebook</a>
							<a class="twitter" href="#">Twitter</a>
							<a class="skype" href="#">Skype</a>
							<a class="vimeo" href="#">Vimeo</a>
						</span>
					</div>					
				</div>	
			</section>
			<section id="copyright">
				<span>Copyright 2013 bootstrappage template  All right reserved.</span>
			</section>
		</div>
		<script src="themes/js/common.js"></script>
    </body>
</html>