<h2>Contoh Upload Gambar</h2>
<form action="upload.php" method="post" enctype="multipart/form-data" name="FUpload" id="FUpload">
  <p>Judul Gambar :
    <input name="judul_gambar" type="text" id="judul_gambar" size="30" maxlength="30" />
</p>
  <p>File Gambar :
    <input name="nama_file" type="file" id="nama_file" size="30" />
</p>
  <p><input type="submit" name="btnSimpan" id="btnSimpan" value="Simpan" /></p>
</form>
